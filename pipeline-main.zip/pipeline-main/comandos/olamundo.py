
print("Olá mundo")